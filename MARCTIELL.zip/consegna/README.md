# Guida alla predizione

1) Inserire i punti di test nel file `input.csv`

2) Navigare da linea di comando all'interno della cartella

    1) (Opzionale) Installare dipendenze mancanti con 
    `pip install -r requirements.txt`

3) Eseguire lo script con

    `python predict.py`

4) Visionare l'output nel file `output.csv`